#!/usr/bin/perl -w

=begin comments

    extract_tables.pl - Extracts tables from an OpenDocument spreadsheet
    Copyright (C) 2006  J. David Eisenberg

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

=end comments

=cut

use XML::XPath;
use IO::File;
use Data::Dumper;
use Carp;
use strict;

my $xpath;		# the XPath tree
my $filename;	# the output filename
my $fh;			# filehandle for the pipe
my @table_nodes;
my @rows;

#
#   Check for one argument: the name of the OpenDocument spreadsheet
#
if (scalar @ARGV != 1 && scalar @ARGV != 2)
{
    croak("Usage: $0 document [outputfile]");
}


#
#   Parse and collect information into an XPath structure
#
$ARGV[0] =~ s/[;|'"]//g;  #eliminate dangerous shell metacharacters
if ($ARGV[1])
{
	($filename = $ARGV[1]) =~ s/[;|'"]//g;
}
else
{
	$filename = "-";
}

open OUTFILE, ">$filename" or croak("Cannot open output file $filename");

$fh = IO::File->new("perl member_read.pl $ARGV[0] content.xml |");
$xpath = XML::XPath->new( ioref => $fh );

@table_nodes = $xpath->findnodes("/office:document-content/office:body/"
	. "office:spreadsheet/table:table");

emit_html_header();

foreach my $table (@table_nodes)
{
	print OUTFILE "<h1>", $table->getAttribute( "table:name" ), "</h1>\n";
	print OUTFILE "<table class=\"open\">\n";
	if ($xpath->exists( "table:table-header-rows", $table ))
	{
		print OUTFILE "<thead>\n";
		@rows =$xpath->findnodes("table:table-header-rows/table:table-row",
			$table);
		process_rows("th");
		print OUTFILE "</thead>\n";
	}
	@rows = $xpath->findnodes("table:table-row", $table);
	print OUTFILE "<tbody>\n";
	process_rows("td");
	print OUTFILE "</tbody>\n";
	print OUTFILE "</table>\n";
}
print OUTFILE "</body>\n</html>\n";

sub process_rows
{
	my $element_name = shift;
	my $row;
	my @cells;
	my $cell;
	my @para;
	my $attr;
	my $count;
	foreach $row (@rows)
	{
		@para = $xpath->findnodes( "table:table-cell[1]/text:p", $row );
		if (scalar @para > 0)
		{
			print OUTFILE "<tr>\n";
			@cells = $xpath->findnodes( "table:table-cell", $row );
			while (@cells > 0)
			{
				$cell = shift @cells;
				#	Ignore a last empty cell. This avoids problems with
				#	"phantom cells" like this at the end of a row:
				#	   <table:cell table:number-columns-repeated="247"/>
				next if (scalar @cells == 0 and
					$xpath->exists("text:p", $cell) == 0);
				
				$attr = $cell->getAttribute( "table:number-columns-repeated" );
				$count = ($attr) ? $attr : 1;
				for (my $i=0; $i < $count; $i++)
				{
					print OUTFILE "<$element_name";
					if ($cell->getAttribute("office:value-type") eq "float")
					{
						print OUTFILE " align=\"right\"";
					}
					print OUTFILE ">";
					@para = $xpath->findnodes( "text:p", $cell );
					if (scalar @para > 0)
					{
						print OUTFILE $xpath->getNodeText( $para[0] );
					}
					else
					{
						print OUTFILE "<br />";
					}
					print OUTFILE "</$element_name>\n";
				}
			}
			print OUTFILE "</tr>\n";
		}
	}
}

sub emit_html_header
{
	print OUTFILE <<"HDR";
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<title>Tournament Attendance</title>
<style type="text/css">
body {
	font-family: sans-serif;
}	

table.open td {
	border: 1px solid gray;
	margin: 3px; padding: 3px;
}

table.open th {
	border-width: 0 2px 2px 0;
	border-style: none solid solid none;
	border-color: gray;
	margin: 3px; padding: 3px;
}
</style>
</head>
<body>
HDR
}
