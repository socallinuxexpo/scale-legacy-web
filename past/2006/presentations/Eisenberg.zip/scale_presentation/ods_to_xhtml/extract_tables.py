import zipfile
import sys
from xml import xpath
from xml.dom.ext.reader import Sax2
from xml.dom import Document, Node, Element, Attr, NodeList
from string import Template
"""
    extract_tables.py - Extract tables from OpenDocument spreadsheet
    Copyright (C) 2006  J. David Eisenberg

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

"""
def emitHeader( ):
		outFile.write( """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<title>Tournament Attendance</title>
<style type="text/css">
body {
	font-family: sans-serif;
}	

table.open td {
	border: 1px solid gray;
	margin: 3px; padding: 3px;
}

table.open th {
	border-width: 0 2px 2px 0;
	border-style: none solid solid none;
	border-color: gray;
	margin: 3px; padding: 3px;
}
</style>
</head>
<body>
""")

def processRow( elementName, row ):
	cellList = row.getElementsByTagNameNS( tableNS, "table-cell" )
	
	#	check for text in first cell
	if (cellList[0].getElementsByTagNameNS( textNS, "p") != []):
		outFile.write("<tr>\n")

		for i in range(len(cellList)):
			cell = cellList[i]
			
			#	Ignore a last empty cell. This avoids problems with
			#	"phantom cells" like this at the end of a row:
			#	   <table:cell table:number-columns-repeated="247"/>
			if (i != len(cellList)-1 or cell.hasChildNodes()):

				#	Find out how many times to repeat this cell.
				#	Note: getAttributeNS returns a string.
				count = cell.getAttributeNS( tableNS,
					"number-columns-repeated")
				if (not count):
					count = 1
				else:
					count = int(count)	# which must be converted to integer

				paraList = cell.getElementsByTagNameNS( textNS, "p" )
				for j in range(count):
					outFile.write("<" + elementName)
					if (cell.getAttributeNS( officeNS, "value-type") ==
						"float"):
							outFile.write(" align=\"right\"")
					outFile.write(">")
					if (len(paraList) > 0):
						outFile.write( paraList[0].firstChild.data)
					else:
						outFile.write("<br />")
					outFile.write("</" + elementName + ">\n")

		outFile.write("</tr>\n")


tableNS = "urn:oasis:names:tc:opendocument:xmlns:table:1.0"
officeNS = "urn:oasis:names:tc:opendocument:xmlns:office:1.0"
textNS = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"

if (len(sys.argv) == 2 or len(sys.argv) == 3):
	filename = sys.argv[1]
	try:
		inFile = zipfile.ZipFile( filename )
		xmlString = inFile.read( "content.xml" )
	except KeyError:
		print "Cannot find content.xml in zip file"
		sys.exit(0)
	except zipfile.BadZipfile:
		print filename, "is not a zip file."
		sys.exit(0)
	
	if (len(sys.argv) == 3):
		outFile = file( sys.argv[2], "w" )
	else:
		outFile = sys.stdout
	
	reader = Sax2.Reader()
	doc = reader.fromString( xmlString )
	emitHeader()
	tableList = doc.getElementsByTagNameNS( tableNS, "table" )
	for table in tableList:
		outFile.write ("<h1>")
		outFile.write(table.getAttributeNS(tableNS, "name"))
		outFile.write("</h1>\n")
		outFile.write("<table class=\"open\">\n")
		rowList = table.getElementsByTagNameNS( tableNS, "table-header-rows")
		if (len(rowList) > 0):
			outFile.write("<thead>\n")
			rowList = rowList[0].getElementsByTagNameNS( tableNS, "table-row")
			for row in rowList:
				processRow( "th", row )
			outFile.write("</thead>\n")

		rowList = table.getElementsByTagNameNS( tableNS, "table-row" )
		outFile.write("<tbody>\n")
		for row in rowList:
			processRow( "td", row )
		outFile.write("</tbody>\n")
		outFile.write("</table>\n")

	outFile.write("</body>\n</html>\n")
	outFile.close()
else:
	print "Usage: " + sys.argv[0] + " inputfile [outputfile]"

	

