#!/usr/local/bin/ruby
require 'rexml/document'
require 'zip/zip'
require 'stringio'

#    extract_tables.rb - Extract tables from OpenDocument spreadsheet
#    Copyright (C) 2006  J. David Eisenberg
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

class Extract_Tables

	def initialize( )
	
		@doc = nil
		@zipfile = nil
		@outfile = nil
		
		@ns_hash = {
			"office" => "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
			"text" => "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
			"table" => "urn:oasis:names:tc:opendocument:xmlns:table:1.0"
		}
		
		if (ARGV.length != 1 && ARGV.length != 2)
			usage()
			exit()
		end
	end

	def extract
		if (ARGV.length == 1)
			@outfile = STDOUT
		else
			@outfile = File.open( ARGV[1], "w" )
		end
		
		#	Create xml document
		@doc = get_xml( ARGV[0], "content.xml" )
		if (@doc != nil)
			emit_header()
			REXML::XPath.each( @doc.root,
			"/office:document-content/office:body/" +
			"office:spreadsheet/table:table",
			@ns_hash) do |table|
				process_table( table )
			end
			@outfile.print( "</body>\n</html>\n" )
		end
	end

	def get_xml( input_filename, member_name )
		begin
		zipfile = Zip::ZipFile::open( input_filename )
		stream = zipfile.get_entry( member_name ).get_input_stream
		doc = REXML::Document.new stream.read
		zipfile.close
		
		rescue
			doc = nil
		end
		return doc
	end

	def emit_header
		@outfile.print <<"HDR"
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<title>Tournament Attendance</title>
<style type="text/css">
body {
	font-family: sans-serif;
}	

table.open td {
	border: 1px solid gray;
	margin: 3px; padding: 3px;
}

table.open th {
	border-width: 0 2px 2px 0;
	border-style: none solid solid none;
	border-color: gray;
	margin: 3px; padding: 3px;
}
</style>
</head>
<body>
HDR
	end

	def process_table( table )
		@outfile.print( "<h1>" +
			table.attribute( "name", @ns_hash['table'] ).value +
			 "</h1>\n")
		@outfile.print("<table class=\"open\">\n")
		if (REXML::XPath.first( table, 'table:table-header-rows', @ns_hash) != nil)
			@outfile.print( "<thead>\n" )
			REXML::XPath.each( table, 'table:table-header-rows/table:table-row',
			@ns_hash) do |row|
				process_row( row, "th" )
			end
			@outfile.print( "</thead>\n" )
		end
		
		@outfile.print( "<tbody>\n" )
		REXML::XPath.each( table, 'table:table-row', @ns_hash) do |row|
			process_row( row, "td" )
		end
		@outfile.print( "</tbody>\n" )
		@outfile.print( "</table>\n" )
	end

	def process_row( row, element_name )
		row_list = REXML::XPath.match( row,
			"table:table-cell[1]/text:p", @ns_hash)
		if (row_list.length > 0)
			@outfile.print( "<tr>\n" )
			cell_list = REXML::XPath.match( row, "table:table-cell",
				@ns_hash)
			cell_list.each_index do |i|
				if (i != cell_list.length-1 or REXML::XPath.first(
					cell_list[i], "text:p", @ns_hash) != nil)
					process_cell( cell_list[i], element_name )
				end
			end
		end
	end

	def process_cell( cell, element_name )
		attr = cell.attribute( "number-columns-repeated",
			@ns_hash['table'] )
		count = (attr == nil ) ? 1 : attr.value.to_i
		attr = cell.attribute("value-type",
			@ns_hash['office'])
		is_float = (attr == nil ) ? false : attr.value == "float"
		for j in 1..count
			@outfile.print( "<#{element_name}" )
			if (is_float)
				@outfile.print " align=\"right\""
			end
			@outfile.print(">")
			para_list = REXML::XPath.match( cell, "text:p", @ns_hash)
			if (para_list.length > 0)
				@outfile.print( para_list[0].text )
			else
				@outfile.print( '<br />' )
			end
			@outfile.print "</#{element_name}>\n"
		end
	end

	def usage
		puts "Usage: #{$0} inputfile [outputfile]"
	end

end

app = Extract_Tables.new
app.extract()

