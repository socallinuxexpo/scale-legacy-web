#!/usr/bin/perl
=begin comments

    member_read.pl - Read a member from a .ZIP or .JAR file
    Copyright (C) 2006  J. David Eisenberg

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

=end comments

=cut

use Archive::Zip;
use Archive::Zip::MemberRead;
use Carp;
use strict 'vars';

my $zip;		# the zip file
my $fh;			# filehandle to the member being read
my $buffer;		# 32 kilobyte buffer

#
#	Extract a single XML file from an OpenOffice.org file
#	Output goes to standard output
#
if (scalar @ARGV != 2)
{
	croak("Usage: $0 document xmlfilename");
}

$zip = new Archive::Zip($ARGV[0]);
if (!$zip)
{
	croak("$ARGV[0] cannot be opened as a .ZIP file");
}

$fh  = new Archive::Zip::MemberRead($zip, $ARGV[1]);
if (!$fh)
{
	croak("$ARGV[0] does not contain a file named $ARGV[1]");
}

while ($fh->read($buffer, 32*1024))
{
	print $buffer;
}
