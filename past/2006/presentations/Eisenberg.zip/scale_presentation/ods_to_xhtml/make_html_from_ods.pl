#!/usr/bin/perl

=begin comments

    make_html_from_ods.pl - Makes HTML from a specifically-formatted
	   OpenDocument spreadsheet
    Copyright (C) 2006  J. David Eisenberg

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

=end comments

=cut

use Archive::Zip;
use XML::DOM;

#
#	List of files to analyze
#
#
@filelist = qw( 
	midgets_fs
	novice_fs 
	schoolboy_fs
	cadet_fs
	junior_fs 
	open_fs
);
#	cadet_greco
#	junior_greco
#	open_greco

#
#	Names for the links at the top of the page
#
@linklist = (
	"Midgets", "Novice",
	"Schoolboy", 
	"Cadet",
	"Junior",
	"Open"
);

sub makeDOM
{
	my ($filename) = shift;
	my $zip = Archive::Zip->new( $filename );
	my $parser = new XML::DOM::Parser;
	my $doc;
	
	$zip->extractMember( "content.xml", "/tmp/workfile" );

	$doc = $parser->parsefile( "/tmp/workfile" );
	return $doc;
}

sub getFirstChildElement
{
	my ($node, $name) = @_;
	for my $child ($node->getChildNodes)
	{
		if ($child->getNodeName eq $name)
		{
			return $child;
		}
	}
	return undef;
}

sub getNextSiblingElement
{
	my ($node, $name) = @_;
	
	while (($node = $node->getNextSibling) &&
		$node->getNodeName ne $name)
	{
		# do nothing
		;
	}
	
	return $node;
}

sub getRowContents
{
	my ($itemRef, $rowNode, $rowNumber) = @_;
	my $cell, $para;
	my $value;
	my $n_repeat;
	my $i;

	@{$itemRef} = ();
	$cell = getFirstChildElement( $rowNode, "table:table-cell" );
	while ($cell)
	{
		$n_repeat = $cell->getAttribute("table:number-columns-repeated");
		$n_repeat = 1 if (!$n_repeat);
		
		$value = "";
		$para = getFirstChildElement( $cell, "text:p" );
		if ($para)
		{
			$value = $para->getFirstChild->getNodeValue;
		}
		for ($i=0; $i < $n_repeat; $i++)
		{
			push @{$itemRef}, $value;
		}
		$cell = getNextSiblingElement( $cell, "table:table-cell" );
	}
}

sub alpharank
{
	my (@itemsA, @itemsB);

	@itemsA = split /\t/, $a;
	@itemsB = split /\t/, $b;
	if ($itemsA[3] > $itemsB[3])
	{
		return -1;
	}
	elsif ($itemsA[3] < $itemsB[3])
	{
		return 1;
	}
	else
	{
		if ($itemsA[1] ne $itemsB[1])
		{
			return $itemsA[1] cmp $itemsB[1];
		}
		else
		{
			return $itemsA[0] cmp $itemsB[0];
		}
	}
}

sub multiLink
{
	my ($n) = @_;
	my ($i, $total);
	$total = scalar @linklist;
	print OUTFILE "<p style=\"text-align: center\">\n";
	print OUTFILE "<a href=\"grand.html\">Index</a> |\n";

	for ($i = 0; $i < $total; $i++)
	{
		if ($i != $n)
		{
			print OUTFILE "<a href=\"$filelist[$i].html\">$linklist[$i]</a>";
		}
		else
		{
			print OUTFILE "<span class=\"thislink\">$linklist[$i]</span>";
		}
		if ($i == 4)
		{
			print OUTFILE "<br />\n";
		}
		elsif ($i != $total-1)
		{
			print OUTFILE " |\n";
		}
		else
		{
			print OUTFILE "\n";
		}
	}
	print OUTFILE "</p>\n";
}


$fileNumber = 0;
for ($file = 0; $file < scalar @filelist; $file++)
{
	$item = $filelist[$file];

	$shortName = $item;
	open OUTFILE, ">$shortName.html";
	print "Processing $item\n";
	
	$doc = makeDOM( "${item}_standings.ods" );
	
	
	($age, $style) = split(/_/, $item);
	$age = ucfirst( $age );
	$style = ($style =~ m/fs/i) ? "Folkstyle/Freestyle" : "Greco";

	print OUTFILE <<"HEADER";
<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1" />
<style type="text/css" media="screen">\@import "scvwa.css";</style>
<style type="text/css" media="print">\@import "pscvwa.css";</style>
<title>$age $style</title>
</head>

<body>
<div id="wrapper">
<div id="top-navig">
<a id="top"></a>
<a href="../index.html">SCVWA Home Page</a>
&gt;
<a href="grand.html">Grand Championship</a>
&gt;
$age $style
</div>

<div id="pageContent">
<h3>$age $style</h3>
HEADER
	
	multiLink( $fileNumber );

	print OUTFILE "<table class=\"open\">\n";
	
	$rows = $doc->getElementsByTagName( "table:table-row" );

	print OUTFILE "<thead><tr><th>Name</th><th>Team</th>";
	print OUTFILE "<th>Total<br />Points</th>";

	$nRows = $rows->getLength;
	print "File $item has $nRows rows ";
	
	getRowContents( \@items, $rows->item(1));
	
	$nColumns = 0;
	while ($items[$nColumns]) { $nColumns++; }
	print "with $nColumns columns.\n";
	
	for ($i=3; $i<$nColumns; $i++)
	{
		print OUTFILE "<th>$items[$i]</th>";
		print OUTFILE "\n" if ($i % 3 == 2);
	}
	print OUTFILE "</tr></thead>\n";
	
	undef @unsorted;
	
	$rowNumber = 2;
	for ($rowNumber = 2; $rowNumber < $nRows; $rowNumber++)
	{
		getRowContents( \@items, $rows->item( $rowNumber ) );
		next if (!$items[0]);
		$sum = 0;
		splice @items, 3, 0, 0;
		for ($i=4; $i<$nColumns+1; $i++)
		{
			next if (!$items[$i]);
			if ($items[$i] < 0)
			{
				$items[$i] = -$items[$i];
			}
			else
			{
				$items[$i] = 4 - $items[$i];
			}
			$sum += $items[$i];
		}
		$items[3] = $sum;
		$data = join("\t", @items);

		push @unsorted, $data;
	}
	@sorted = sort alpharank @unsorted;
	close INFILE;

	print OUTFILE "<tbody>\n";
	foreach $data (@sorted)
	{
		@items = split /\t/, $data;
		print OUTFILE "<tr align=\"right\">";
		$items[1] = $items[0] . " " . $items[1];
		shift @items;

		$items[0] =~ s/\~n/\&ntilde\;/;
		$items[0] =~ s/\~a/\&aacute\;/;
		$items[0] =~ s/\~e/\&eacute\;/;
		$items[0] =~ s/\~i/\&iacute\;/;
		$items[0] =~ s/\~o/\&oacute\;/;
		$items[0] =~ s/\~u/\&uacute\;/;

		for ($i=0; $i<$nColumns; $i++)
		{
			if ($items[$i] eq "")
			{
				$items[$i] = "<br />";
			}
			$align = ($i < 2) ? " align=\"left\"" : "";
			print OUTFILE "<td$align>$items[$i]</td>";
			print OUTFILE "\n" if ($i % 3 == 2);
		}
		print OUTFILE "</tr>\n";
	}
	print OUTFILE "</tbody>\n</table>\n\n";
	multiLink($fileNumber);
	print OUTFILE <<"FOOTER";
</div>
</div>
</body>
</html>
FOOTER
	$fileNumber++;
}
close OUTFILE;
