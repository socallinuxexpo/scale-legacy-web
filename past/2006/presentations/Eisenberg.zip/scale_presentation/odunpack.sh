if [[ $# == 1 ]]
then
	odname=$1
	dirname=$( echo $odname | tr '.' '_' )
	unzip -d $dirname -o -q $odname
else
	echo "Usage: $0 filename.odf"
fi


