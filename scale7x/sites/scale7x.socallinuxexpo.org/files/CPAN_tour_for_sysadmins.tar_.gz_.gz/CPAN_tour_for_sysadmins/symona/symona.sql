CREATE TABLE `device_stat` (
  `id` int(11) NOT NULL auto_increment,
  `device` varchar(255) default NULL,
  `value` int(11) default NULL,
  `time_collected` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
);
