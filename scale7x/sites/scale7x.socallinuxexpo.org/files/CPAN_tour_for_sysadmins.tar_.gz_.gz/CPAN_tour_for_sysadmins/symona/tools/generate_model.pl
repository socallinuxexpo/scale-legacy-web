#!/usr/bin/perl

use warnings;
use strict;

use lib q{../lib};
use Symona::DB;
use Rose::DB::Object::Loader;

my $db = Symona::DB->new();
my $loader = Rose::DB::Object::Loader->new(
    db           => Symona::DB->new(),
    class_prefix => 'Symona::DBO',
    base_class   => 'Symona::DBO'
);

$loader->make_modules(
    module_dir          => '/home/scale/symona/lib/',
    with_managers       => 1,
    with_relationships  => 1
);

exit;
