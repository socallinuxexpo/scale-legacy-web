package Symona::Plugin::PingDatabase;

use DBI;

use Carp;
use Mouse;

extends 'Symona::Spotter::Timer', 'Symona::EmailNotifier';

sub callback {
    my $self = shift;
    my %args = @_;

    my $dsn = "DBI:mysql:database=$args{database};host=$args{hostname};port=3306";
    
    my $dbh;
    eval {
        $dbh = DBI->connect($dsn, $args{username}, $args{password}, {PrintError => 0}) or croak($DBI::errstr);
    };
    if ($@) {
        $self->notify($args{notify}, "unable to connect to $args{database} at $args{hostname}", $DBI::errstr);
    }
}

1;
