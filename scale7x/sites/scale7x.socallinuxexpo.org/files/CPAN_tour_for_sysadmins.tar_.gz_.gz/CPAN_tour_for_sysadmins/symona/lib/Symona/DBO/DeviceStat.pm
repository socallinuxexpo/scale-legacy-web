package Symona::DBO::DeviceStat;

use strict;

use base qw(Symona::DBO);

__PACKAGE__->meta->setup(
    table   => 'device_stat',

    columns => [
        id             => { type => 'serial', not_null => 1 },
        device         => { type => 'varchar', length => 255 },
        value          => { type => 'integer' },
        time_collected => { type => 'timestamp', not_null => 1 },
    ],

    primary_key_columns => [ 'id' ],
);

1;

