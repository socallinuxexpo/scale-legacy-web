package Symona::Spotter;

use Mouse;

with 'Symona::Callbackable';

sub watch {
    my ($self, %args) = @_;
    $self->watcher(%args);
}

1;
