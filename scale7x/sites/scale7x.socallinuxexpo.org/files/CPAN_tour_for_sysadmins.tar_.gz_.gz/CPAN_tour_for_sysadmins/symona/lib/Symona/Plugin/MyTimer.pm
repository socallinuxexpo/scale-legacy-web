package Symona::Plugin::MyTimer;

use Carp;
use Mouse;

extends 'Symona::Spotter::Timer';

sub callback {
    my $self = shift;
    my %args = @_;
    open (my $fh, '>>', $args{base_path}.$$.".log") or croak $!;
    print $fh time()." $args{message}\n";
    close ($fh) or croak $!;
}

1;
