package Symona::Plugin::SNMP;

use Net::SNMP;

use Carp;
use Mouse;

extends 'Symona::Spotter::Timer';

sub callback {
    my $self = shift;
    my %args = @_;

    my ($session, $error) = Net::SNMP->session(
        -hostname   => $args{snmp_host}, 
        -community  => $args{community},
        -port       => 161
    );

    my $result = $session->get_request(-varbindlist => $args{mibs});
    
    my $store = $args{store};

    # make sure we're getting a class name
    croak "Invalid class name: $store" unless ($store =~ /^\w+(\:\:\w+)*$/);
    # load it
    eval "require $store";

    for (my $i = 0; $i < @{ $args{mibs} } ; $i++) {
        my $o = $store->new(device => $args{mibs}->[$i], value => $result->{ $args{mibs}->[$i] });
        $o->save();
    }
}

1;
