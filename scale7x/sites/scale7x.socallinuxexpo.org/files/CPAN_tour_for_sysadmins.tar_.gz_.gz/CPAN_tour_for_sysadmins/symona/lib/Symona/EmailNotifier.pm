package Symona::EmailNotifier;

use MIME::Lite;
use Mouse;

sub notify {
    my $self = shift;
    my ($recipient, $subject, $message) = @_;
    my $email = MIME::Lite->new(
        'To'        => $recipient,
        'Subject'   => $subject,
        'Data'      => $message
    );
    $email->send();
};

1;
