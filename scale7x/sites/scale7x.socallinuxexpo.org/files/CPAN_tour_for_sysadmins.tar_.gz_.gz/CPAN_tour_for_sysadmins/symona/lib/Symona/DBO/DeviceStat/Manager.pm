package Symona::DBO::DeviceStat::Manager;

use strict;

use base qw(Rose::DB::Object::Manager);

use Symona::DBO::DeviceStat;

sub object_class { 'Symona::DBO::DeviceStat' }

__PACKAGE__->make_manager_methods('device_stat');

1;

