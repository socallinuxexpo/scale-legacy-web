package Symona::Callbackable;

use Mouse::Role;

around 'watch' => sub {
    my $orig = shift;
    my $self = shift;
    my %args = @_;
    # create the spotter
    my $w = $self->$orig( %{ $args{setup_args} }, parked => 1 );
    $w->cb(
        sub { 
            $self->callback( %{ $args{task_args} } ); 
        }
    );
    $w->start();
};

1;
