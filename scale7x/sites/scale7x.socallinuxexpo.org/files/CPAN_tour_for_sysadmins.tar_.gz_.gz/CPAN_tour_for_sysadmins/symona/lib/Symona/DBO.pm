package Symona::DBO;

use warnings;
use strict;

use Carp;
use Symona::DB;
use base qw(Rose::DB::Object);

sub init_db { Symona::DB->new() }

sub manager {
    my $class = shift;
    $class .= '::Manager';
    eval "require $class";
    croak ($@) if $@;
    return $class;
}

1;
