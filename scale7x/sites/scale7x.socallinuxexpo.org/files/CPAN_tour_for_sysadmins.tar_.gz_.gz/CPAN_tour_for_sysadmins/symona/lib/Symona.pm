package Symona;

use warnings;
use strict;

use Proc::Daemon;
use Getopt::Std;
use Config::Any;
use Event qw(loop);

use Sub::Exporter -setup => { 
    exports => [ qw(start) ],
    groups  => {
        default => [ qw(start) ]
    }
};

use Carp;

our %options;
our $config;
our %spotters;
our @spotters;

sub start {
    getopt('fd', \%options);
    Proc::Daemon::Init();
    read_configuration();
    deploy_spotters();
    loop();
}

sub read_configuration {
    my $file = (exists $options{f} && $options{f}) ? $options{f} : '/etc/symona/symona.json';
    croak("Configuration file $file not found\n") unless -e $file;
    croak("Unable to read $file not found\n") unless -r _;
    croak("Configuration file $file is empty\n") unless -s _;
    $config = ${Config::Any->load_files({files => [ $file ], use_ext => 1})}[0]{$file};
    $config->{configuration_file} = $file;
}

sub deploy_spotters {
    my $spotters = $config->{watchers};
    foreach my $group (keys %$spotters) {
        # load spotter classes
        my $class = "Symona::Plugin::$group";
        croak "Invalid class name: $class" unless ($class =~ /^\w+(\:\:\w+)*$/);
        eval "require $class";
        foreach my $args (@{ $spotters->{$group} }) {
            # launch spotter
            my $s = $class->new();
            $s->watch(%$args);
            $spotters{ref $s} = $s;
        }
    }
}

1;
