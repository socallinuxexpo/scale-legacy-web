package Symona::Spotter::Timer;

use Event;
use Mouse;

extends 'Symona::Spotter';

sub watcher {
    shift;
    return Event->timer(@_);
};

1;
