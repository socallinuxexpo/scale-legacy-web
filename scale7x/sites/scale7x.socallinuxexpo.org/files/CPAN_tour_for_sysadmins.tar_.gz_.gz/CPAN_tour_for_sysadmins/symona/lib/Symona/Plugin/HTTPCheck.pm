package Symona::Plugin::HTTPCheck;

use WWW::Mechanize;
use Carp;
use Mouse;

extends 'Symona::Spotter::Timer', 'Symona::EmailNotifier';

sub callback {
    my $self = shift;
    my %args = @_;
    
    eval {
        my $mech = WWW::Mechanize->new();
        $mech->get($args{url});
        if (!$mech->success()) {
            $self->notify($args{notify}, "HTTPCheck Failed for $args{url}", $mech->content());
        }    
    };
}

1;
