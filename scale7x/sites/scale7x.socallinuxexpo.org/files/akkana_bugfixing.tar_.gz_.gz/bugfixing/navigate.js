// JavaScript Slide Presentation software.
// Copyright 2003-2009 by Akkana Peck.
// This software is licensed under the GNU public license --
// Share and enjoy!

// See a presentation on how to use this at
// http://shallowsky.com/linux/presentations/

//
// Slide navigation. List your slides here, in order.
//
var slides = new Array ( "index.html",
                         "youcanfixbugs.html",
                         "bs.html",
                         "you.html",
                         "purpose.html",
                         "english-sortof.html",

                         "andrew-morton.html",
                         "dontpanic1.html",

                         "mystery.html",
                         "mystery2.html",
                         "mystery3.html",
                         "mystery4.html",
                         "mystery5.html",
                         "mystery6.html",

                         "simple.html",
                         "wargames.html",
                         "wargames2.html",
                         "unclear.html",
                         "wargames-mystery.html",
                         "which.html",
                         "file-cmd.html",
                         "scripts.html",
                         "wargamescode.html",
                         "dontpanic2.html",
                         "wargamescode2.html",
                         "hacking-script.html",
                         "homebin.html",
                         "wargamescode-fixed.html",
                         "wargames-fixed.html",
                         "wow-easy.html",
                         "just-text.html",
                         "if-else.html",
                         "verbs.html",
                         "echo.html", "echo-fixed.html",
                         "one-more-thing.html",
                         "nouns.html",
                         "dollar-x.html",
                         "add-dollar-x.html",
                         "wargames-fixed2.html",
                         "littlebug.html",
                         "biggerbug.html",
                         "littlebiggerbug.html",

                         "c-code.html",
                         "gimp.html",
                         "checkbox.html",
                         //"get-the-source.html",
                         //"distro-src.html",
                         "tarballs.html",
                         "builddeps.html",
                         "no-install.html",
                         "run.html",
                         "search-src.html",
                         "search-src2.html",
                         "grep.html", "grep2.html", "grep3.html",
                         //"grepflags.html",
                         "show-preview.html",
                         "grep-r.html",
                         "grep-show-preview.html",
                         "grep-preview-in.html",
                         "pipelines.html",
                         "grep-v.html",
                         "po-pipeline.html",
                         "texteditor.html",
                         //"texteditorbells.html",
                         //"emacs-match-paren.html",
                         "jpeg-save-c.html",
                         "underscore.html",
                         "jpeg-save-c2.html",
                         "jpeg-save-c3.html",
                         "set-active.html",
                         "set-active2.html",
                         "GtkToggleButton.html",
                         "toggle-on.html",
                         "fixed-dialog.html", "fixed-dialog2.html",
                         "deadbee.html",

                         "makepatch.html",
                         "botchedfix.html",

                         "bugs-to-fix.html",

                         "crashes.html",
                         "biggerbug2.html",
                         "gdb.html",
                         //"backquotes.html",
                         "gdb-where.html",
                         "no-core.html",
                         "stacktraces.html",

                         "hardbugs.html",
                         "hardtosee.html",
                         "designflaw.html",

                         "tom-sawyer.html",

                         "reportbug.html",
                         "bugsystem.html",
                         "ubuntubugs.html",
                         "Bugzilla@Mozilla.html",
                         "gnomequery.html",

                         "whybugsystem.html",
                         "maybehard.html",

                         "newbug.html",
                         //"not-existing.html",
                         "describe.html",
                         "descriptions.html",
                         "whydescribe.html",
                         "bugdetails.html",
                         "followups.html",

                         "applypatch.html", "applypatch2.html",
                         "qa.html",
                         "summary.html",

                         // Bonus slides
                         "blank.html",
                         "bonus.html",
                         "firefox-bugs.html",
                         "firefox-jars.html",
                         "gimp-scripts.html",
                         "gimp-coffee.html",
                         "cowsay.html",
                         "cowsay-h.html",
                         "cowsay-code.html",
                         "cowsay-diff.html",
                         "bonus-end.html"
                         );

//
// Add the event listener.
// This actually only has to be done for the first slide.
if (document.addEventListener)		// DOM way
  document.addEventListener("keypress", onKeyPress, false);
else if (document.all)			// IE way
  document.attachEvent("onkeypress", onKeyPress);

//
// Keypress navigation
function onKeyPress(e)
{
  // IE doesn't see the event argument passed in, so get it this way:
  if (window.event) e = window.event;

  // Mozilla uses charCode for printable characters, keyCode for unprintables:
  if (e.charCode) {
    switch (e.charCode) {
      case 32:
        nextSlide();
        e.preventDefault();
        return;
      // The Logitech Presenter sends a period from the "blank screen" btn
      case 46:
        blankScreen();
        e.preventDefault();
        return;
    }
  }

  //alert("key press, char code " + e.charCode + ", key code " + e.keyCode );

  if (e.shiftKey == 1) {
    switch (e.keyCode) {
      case 33:    // e.DOM_VK_PAGE_UP:
      case 33:    // e.DOM_VK_PAGE_UP:
        tableOfContents();
        e.preventDefault();
        return;
    }
    return;
  }
  if (e.ctrlKey == 1 || e.altKey == 1) {
    return;
  }

  // Use numeric values rather than DOM_VK_* so that non-mozilla browsers
  // might work.
  switch (e.keyCode) {
    case 32:    // e.DOM_VK_SPACE:
    case 34:    // e.DOM_VK_PAGE_DOWN:
    case 39:    // e.DOM_VK_RIGHT:
      nextSlide();
      e.preventDefault();
      return;
    case 8:     // e.DOM_VK_BACK_SPACE:
    case 33:    // e.DOM_VK_PAGE_UP:
    case 37:    // e.DOM_VK_LEFT:
      prevSlide();
      e.preventDefault();
      return;
    case 36:    // e.DOM_VK_HOME:
    //case 38:    // e.DOM_VK_UP:
      firstSlide();
      e.preventDefault();
      return;
    case 35:    // e.DOM_VK_END:
      lastSlide();
      e.preventDefault();
      return;
    // The Logitech Presenter's F5/ESC button sometimes sends ESC,
    // sometimes F5. I can't figure out the rule, so treat them the same:
    case 27:     // e.DOM_VK_ESC:
    case 116:    // e.DOM_VK_F5:
      firstSlide();
      e.preventDefault();
      return;
  }
}

//
// Initialize anything needed to show points one by one.
// To use this, set up an ol or ul with id="points"
// and in the HTML body, call onload="initPoints()"
// By default nothing will be visible to begin with;
// if you want something visible, pass 1 or more as the argument.
//
var points;
var curPoint = 0;
var lastPoint;
function initPoints(numvis)
{
  numvis = typeof(numvis) == 'undefined' ? 0 : numvis;

  // Set up the point nav:
  var pointList = document.getElementById("points");
  if (pointList) {
    points = pointList.getElementsByTagName("li");
    // Make the first point visible (they should all be invisible initially)
    //points[curPoint].style.visibility = "visible";
  }
  while (numvis > 0) {
    points[curPoint].style.visibility = "visible";
    curPoint = curPoint + 1;
    numVis = numVis - 1;
  }
}

function indexOfPage() {
  var url = document.URL;
  var lastslash = document.URL.lastIndexOf("/");
  var filename = url.substring(lastslash+1, url.length);
//alert(filename);

  // JS 1.6 has Array.indexOf, but that doesn't work in Opera/Konq/etc.
  if (slides.indexOf) return slides.indexOf(filename);
  var i;
  for (i=0; i<slides.length; ++i) {
    if (slides[i] == filename) return i;
  }
  return 0;
}

function nextSlide() {
  // If there are multiple points on this slide, show the next point:
  if (points && curPoint < points.length) {
    // Make old-current point a more subtle color,
    // to emphasize only the new-current point.
    if (curPoint > 0)
        points[curPoint-1].setAttribute("class", "greyed");
    points[curPoint].style.visibility = "visible";
    curPoint = curPoint + 1;

    return;
  }

  // No next point -- go to the next slide instead.
  var i = indexOfPage();
  if (i >= slides.length - 1) {    // last slide
    //window.alert("That's the last slide");
    return;
  }
  window.location = slides[i+1];
}

function firstSlide() {
  window.location=slides[0];
}

function lastSlide() {
  window.location=slides[slides.length-1];
}

/* Toggle the screen black or not */
function blankScreen() {
  var allblack = document.getElementById("allblack");
  if (allblack) {
    var vis = allblack.style.visibility;
    if (vis == "hidden") {
      allblack.style.visibility = "visible";
    }
    else {
      allblack.style.visibility = "hidden";
    }
  }
  else {
    var body = document.getElementsByTagName("body")[0];
    allblack = document.createElement("div");
    allblack.id = "allblack";
    allblack.style.position = "absolute";
    allblack.style.left = "0";
    allblack.style.top = "0";
    allblack.style.width = "100%";
    allblack.style.height = "100%";
    allblack.style.background = "black";
    allblack.style.zIndex = 100;
    allblack.style.visibility = "visible";
    body.appendChild(allblack);
  }
}

function tableOfContents() {
  // First make a list of all our slides:
  var text = "<h2>Table of Contents</h2>\n<small>\n";
  var i;
  for (i=0; i<slides.length; ++i)
    text += '<a href="' + slides[i] + '">' + slides[i] + '</a><br>\n'
  text += "</small>\n"
  body = document.getElementsByTagName("body")[0];
  body.innerHTML = text;
}

function prevSlide() {
  i = indexOfPage();
  if (i <= 0) {    // last slide
    //window.alert("Already on the first slide");
    return;
  }
  window.location = slides[i-1];
}

