#!/usr/bin/env ruby

# teleprompter for Santa
3.times { puts "HO" }

# tea anyone?
exit unless "I'm a little tea pot".include? "tea" 

['autumn','chad','shawn'].each { |name| puts name.capitalize } 
