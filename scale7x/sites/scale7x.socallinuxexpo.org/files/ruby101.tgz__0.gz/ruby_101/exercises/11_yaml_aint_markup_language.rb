#!/usr/bin/env ruby

# adds a to_yaml method to Object
require 'yaml'


hash = {:first=>'Han',:last=>'Solo',:friends=>['Luke','Chewy']}

File.open 'sw.yml','w+' do |f|
  f.write hash.to_yaml
end

h = YAML.load File.open('sw.yml')
p h