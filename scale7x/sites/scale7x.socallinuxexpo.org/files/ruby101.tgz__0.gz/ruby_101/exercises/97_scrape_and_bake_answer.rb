#!/usr/bin/env ruby

SCALE_SPEAKERS_PAGE = 'http://scale7x.socallinuxexpo.org/conference-info/speakers'

# request the page via Mechanize
# http://mechanize.rubyforge.org/mechanize/

require 'rubygems'
Gem.use_paths(nil,[File.join(File.dirname(__FILE__),'..','gems')])
require 'mechanize'
include WWW
agent = Mechanize.new
page = agent.get SCALE_SPEAKERS_PAGE

# get the speaker links

links = []
page.links.each do |l|
  links << l.href if l.href.include? "speakers/"
end

# follow the speaker links and scrape/massage their bio data

File.open('speakers.txt','w') do |f|
  links.uniq.each do |link|
    page = agent.get link
    bio_text = page.search('//div[@id="main-content-inner"]').text
    bio_text.each_line do |l|
      f.puts l.gsub(/\s\s*/, ' ') unless l.strip.empty? or l.strip == 'Home'
    end
    f.puts
  end
end
