#!/usr/bin/env ruby

class OperatingSystem
  attr_accessor :name
end

class Windows < OperatingSystem
  VERSION = 7
  def initialize
    pay_microsoft
    @name = "bills_box"
  end

  def boot
    puts "trying to boot #{name}.."
    sleep 3
    raise "BSOD"
  end

  def pay_microsoft
    puts "Thank you Bill Gates! Please take my kidney, I don't really want it."
  end

end

class Linux < OperatingSystem

  def initialize
    @name = "happy_penguin"
  end

  def boot
    puts "trying to boot #{name} into #{self.class}"
    puts "running."
    gets
  end
end

if $0 == __FILE__

  win = Windows.new
  begin
    win.boot
  rescue Exception => ex
    puts "something was wrong,[#{ex}]; oh, you were using Windows..."
    os = Linux.new
    os.boot
  end
  
end
