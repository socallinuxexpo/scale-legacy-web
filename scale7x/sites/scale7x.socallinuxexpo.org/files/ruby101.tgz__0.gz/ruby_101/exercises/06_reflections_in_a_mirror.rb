#!/usr/bin/env ruby

p "a string".methods.sort
puts

p 5.methods.sort
puts

p File.methods
puts

p 3.class
puts

p 3.respond_to?(:hi)
puts

p 3.respond_to?(:+)
puts

p Object.constants
puts

p Object.class_variables
@@foo = "taint"
p Object.class_variables