#!/usr/bin/env ruby

module Puree
  def puree
    puts 'wwhhhrrrrrrr!!!'
  end
end

class Blender
  include Puree
  def blend
    puts "bbmmmmm..."
  end
end

b = Blender.new

b.blend

b.puree