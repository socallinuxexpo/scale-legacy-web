#!/usr/bin/env ruby

module Cookable
  class Hours;def initialize(num);end;end
  class Degrees;def initialize(num);end;end
  class ::Fixnum
    def degrees
      Degrees.new(self)
    end

    def hours
      Hours.new(self)
    end
  end
  def cook_at(deg,hours)
    # blah blah
  end
end

class Goose
  include Cookable
  def pluck_feathers
    5.times {puts "honk"}
  end
  def roast
    cook_at 300.degrees, 4.hours
  end
  def carve
    # slicy slice
  end
end

class Duck
  include Cookable
  def pluck_feathers
    5.times {puts "quack"}
  end
  def roast
    cook_at 350.degrees, 3.hours
  end
  def carve
    # slicy slice
  end
end

def make_dinner(bird)
  bird.pluck_feathers
  bird.roast
  bird.carve
end

make_dinner Duck.new
make_dinner Goose.new