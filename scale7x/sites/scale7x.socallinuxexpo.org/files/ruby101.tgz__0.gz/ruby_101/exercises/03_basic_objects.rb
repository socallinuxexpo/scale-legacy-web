#!/usr/bin/env ruby

# String
"This is a String"
'So is this'
String.new("So is this")

# Fixnum
5

# Regexp
/^yo(.*)$/m
Regexp.new("^yo(.*)$", Regexp::MULTILINE)

# Float
5.3

# Array
[1,2,7,9]
Array.new [1,2,7,9]

# Hash
{'yo'=>'mama','boo'=>'yah'}

#Range
1..7

