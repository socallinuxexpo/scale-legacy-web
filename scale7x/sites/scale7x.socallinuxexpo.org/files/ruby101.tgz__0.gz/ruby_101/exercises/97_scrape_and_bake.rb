#!/usr/bin/env ruby

SCALE_SPEAKERS_PAGE = 'http://scale7x.socallinuxexpo.org/conference-info/speakers'

# request the page via Mechanize
# http://mechanize.rubyforge.org/mechanize/
require 'rubygems'
require 'mechanize'

# get the speaker links


# follow the speaker links and scrape/massage their bio data


# see examples/speakers.txt for sample output
