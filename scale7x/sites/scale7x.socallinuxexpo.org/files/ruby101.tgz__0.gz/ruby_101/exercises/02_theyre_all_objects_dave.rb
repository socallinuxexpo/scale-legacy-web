#!/usr/bin/env ruby

puts "hello world"
puts "hello world".class
puts

puts 5
puts 5.class
puts

puts 5.2
puts 5.2.class
puts

puts :foo
puts :foo.class
puts

puts /\w+hello\s*/
puts /\w+hello\s*/.class
puts

puts nil
puts nil.class
puts

puts self
puts self.class

puts "They're all objects Dave"
