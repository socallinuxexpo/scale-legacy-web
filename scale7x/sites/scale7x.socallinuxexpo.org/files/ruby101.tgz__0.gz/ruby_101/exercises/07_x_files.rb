#!/usr/bin/env ruby

CASE_FILE_NAME = 'cases.txt'
SECRET_CASE_FILE_NAME = 'secret_cases.txt'

File.open(CASE_FILE_NAME,'w+') do |f|
  f.puts "UFO sighting"
  f.puts "Bigfoot"
  f.puts "who's that smokey guy"
end


puts File.open(CASE_FILE_NAME).readlines

File.rename CASE_FILE_NAME, SECRET_CASE_FILE_NAME

puts "I found your secrets" if File.exists?(SECRET_CASE_FILE_NAME)

File.delete SECRET_CASE_FILE_NAME

puts "Where'd the secrets go?" unless File.exists?(SECRET_CASE_FILE_NAME)
