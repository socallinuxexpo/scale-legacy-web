#!/usr/bin/env ruby


# looks like we have some built in iterators here
5.times do |i|
  puts "the right stuff #{i}"
end

['donnie','danny','joey','jordan','jonathan'].each { |name| puts name.capitalize }


albums = [
  {:name => 'New Kids on the Block',:rank =>99_999},
  {:name => 'Hangin Tough',:rank => 1},
  {:name => 'Merry, Merry Christmas',:rank => 9},
  {:name => 'Step by Step',:rank => 1},
  {:name => 'Face the Music',:rank => 37}
]
p albums.sort_by{|album| album[:rank]}

